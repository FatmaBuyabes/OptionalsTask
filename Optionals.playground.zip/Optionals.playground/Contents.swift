import UIKit

var number = "1987655A"

print(Int(number) ?? 0) //not sure about the data
//print(Int(number)!) //i am sure about the data

//Exercise 1
var secretMessage: String? = "a message" // String? is optional means it its inside the box its protected
print(secretMessage ?? "No secret message found")


var message: String? = nil // String? is optional means it its inside the box its protected
print(message ?? "No secret message found")


var secret: String? = "secret" // String? is optional means it its inside the box its protected
print(secret!)

//Exercise 2
func performLogin(username: String?, password: String?) {
    if username == nil && password == nil {
        print("Wrong username and password")
    } else if username == nil {
        print("Wrong username")
    } else if password == nil {
        print("Wrong password")
    } else {
        print("Error")
        
    }
}

performLogin(username: nil, password: nil)


